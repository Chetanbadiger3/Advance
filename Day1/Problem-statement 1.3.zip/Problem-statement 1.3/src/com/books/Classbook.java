package com.books;

public class Classbook {

	    private String bookName;
	    private int bookPrice;
	    
	    
	     public void setBookName(String bookName)
	    {
	        this.bookName=bookName;
	    }
	    
	    public String getBookName()
	    {
	        return this.bookName;
	    }
	    
	    public void setBookPrice(int bookPrice)
	    {
	        this.bookPrice=bookPrice;
	    }
	    
	    public int getBookPrice()
	    {
	        return this.bookPrice;
	    }
	    
	    
	}


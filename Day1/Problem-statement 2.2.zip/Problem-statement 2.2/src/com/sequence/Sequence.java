package com.sequence;

public class Sequence {

    public static void main(String[] args) 
    { 
        int count = 13, num1 = 1, num2 = 3; 
        System.out.print("Sequence of Fibonacci "+count+" numbers:"); 
        for (int i = 1; i <= count; ++i) 
        { 
            System.out.print(num1+" "); 
            
            int sumOfPrevTwo = num1 + num2; num1 = num2; num2 = sumOfPrevTwo;
            } 
        
    }
}